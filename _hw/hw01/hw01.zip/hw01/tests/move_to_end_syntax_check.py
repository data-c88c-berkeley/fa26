def move_to_end_syntax_check():
    """Check that your move_to_end code consists of nothing but a return statement.

    >>> # You aren't expected to understand the code of this test.
    >>> import inspect, ast
    >>> from hw01 import move_to_end
    >>> [type(x).__name__ for x in ast.parse(inspect.getsource(move_to_end)).body[0].body]
    ['Expr', 'Return']
    """
    # You don't need to edit this function. It's just here to check your work.
