from pytest_grader import points


@points(0)
def problem_ec2_check():
    r"""
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> # Testing status parameters
    >>> slow = SlowThrower()
    >>> scary = ScaryThrower()
    >>> SlowThrower.food_cost
    LOCKED: aa979d2c89ce4b85
    >>> ScaryThrower.food_cost
    LOCKED: 19220c554f294fd4
    >>> slow.health
    LOCKED: a2f8fe7b5e386d3b
    >>> scary.health
    LOCKED: 9ccf668c5db7d71f
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> # Testing Slow
    >>> slow = SlowThrower()
    >>> bee = Bee(3)
    >>> gamestate.places["tunnel_0_0"].add_insect(slow)
    >>> gamestate.places["tunnel_0_5"].add_insect(bee)
    >>> slow.action(gamestate)
    >>> gamestate.time = 1
    >>> bee.action(gamestate)
    >>> bee.place.name
    LOCKED: 670c20ca630a6686
    >>> gamestate.time += 1
    >>> bee.action(gamestate)
    >>> bee.place.name
    LOCKED: d6afb6f586cfcf99
    >>> for _ in range(3):
    ...    gamestate.time += 1
    ...    bee.action(gamestate)
    >>> bee.place.name
    LOCKED: 7b7efffb162ca74e
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> # Testing Scare
    >>> scary = ScaryThrower()
    >>> bee = Bee(3)
    >>> gamestate.places["tunnel_0_0"].add_insect(scary)
    >>> gamestate.places["tunnel_0_4"].add_insect(bee)
    >>> scary.action(gamestate)
    >>> bee.action(gamestate)
    >>> bee.place.name # ScaryThrower should scare for two turns (first turn)
    LOCKED: 97c65881cacabfa4
    >>> bee.action(gamestate)
    >>> bee.place.name # ScaryThrower should scare for two turns (second turn)
    LOCKED: 4575f851b2bcc9e2
    >>> bee.action(gamestate)
    >>> bee.place.name # ScaryThrower effects have worn off
    LOCKED: f57ec64d4084b9ab
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> # Scary stings an ant
    >>> scary = ScaryThrower()
    >>> harvester = HarvesterAnt()
    >>> bee = Bee(3)
    >>> gamestate.places["tunnel_0_0"].add_insect(scary)
    >>> gamestate.places["tunnel_0_4"].add_insect(bee)
    >>> gamestate.places["tunnel_0_5"].add_insect(harvester)
    >>> scary.action(gamestate)
    >>> bee.action(gamestate)
    >>> bee.place.name # ScaryThrower should scare for two turns
    LOCKED: fbdb83b012aef9c8
    >>> harvester.health
    LOCKED: 7bd6e7954be6972b
    >>> bee.action(gamestate)
    >>> harvester.health
    LOCKED: ffa8a20042d4bd02
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> ScaryThrower.implemented
    LOCKED: 81d025fe651bd50c
    >>> SlowThrower.implemented
    LOCKED: 9e3c5d0de2dd7f37
    """


@points(0)
def problem_ec2():
    r"""
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> # Testing if statuses stack
    >>> slow = SlowThrower()
    >>> bee = Bee(3)
    >>> slow_place = gamestate.places["tunnel_0_0"]
    >>> bee_place = gamestate.places["tunnel_0_8"]
    >>> slow_place.add_insect(slow)
    >>> bee_place.add_insect(bee)
    >>> slow.action(gamestate)    # slow bee two times
    >>> slow.action(gamestate)
    >>> gamestate.time = 1
    >>> bee.action(gamestate) # do nothing. There are 5 turns left with the bee slowed.
    >>> bee.place.name
    'tunnel_0_8'
    >>> gamestate.time = 2
    >>> bee.action(gamestate) # moves forward. There are 4 turns left with the bee slowed.
    >>> bee.place.name
    'tunnel_0_7'
    >>> gamestate.time = 3
    >>> bee.action(gamestate) # do nothing. There are 3 turns left with the bee slowed.
    >>> bee.place.name
    'tunnel_0_7'
    >>> gamestate.time = 4
    >>> bee.action(gamestate) # moves forward. There are 2 turns left with the bee slowed.
    >>> bee.place.name
    'tunnel_0_6'
    >>> gamestate.time = 5
    >>> bee.action(gamestate) # does nothing. There is 1 turn left with the bee slowed.
    >>> bee.place.name
    'tunnel_0_6'
    >>> gamestate.time = 6      # moves forward. The slow status has now worn off
    >>> bee.action(gamestate)
    >>> bee.place.name
    'tunnel_0_5'
    >>> gamestate.time = 7      # slow status has worn off
    >>> bee.action(gamestate)
    >>> bee.place.name
    'tunnel_0_4'
    >>> gamestate.time = 8      # slow status has worn off
    >>> bee.action(gamestate)
    >>> bee.place.name
    'tunnel_0_3'
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> # Testing multiple scared bees
    >>> scare1 = ScaryThrower()
    >>> scare2 = ScaryThrower()
    >>> bee1 = Bee(3)
    >>> bee2 = Bee(3)
    >>> gamestate.places["tunnel_0_0"].add_insect(scare1)
    >>> gamestate.places["tunnel_0_1"].add_insect(bee1)
    >>> gamestate.places["tunnel_0_4"].add_insect(scare2)
    >>> gamestate.places["tunnel_0_5"].add_insect(bee2)
    >>> scare1.action(gamestate)
    >>> scare2.action(gamestate)
    >>> bee1.action(gamestate)
    >>> bee2.action(gamestate)
    >>> bee1.place.name
    'tunnel_0_2'
    >>> bee2.place.name
    'tunnel_0_6'
    >>> bee1.action(gamestate)
    >>> bee2.action(gamestate)
    >>> bee1.place.name
    'tunnel_0_3'
    >>> bee2.place.name
    'tunnel_0_7'
    >>> bee1.action(gamestate)
    >>> bee2.action(gamestate)
    >>> bee1.place.name
    'tunnel_0_2'
    >>> bee2.place.name
    'tunnel_0_6'
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> scare = ScaryThrower()
    >>> bee = Bee(3)
    >>> gamestate.places["tunnel_0_0"].add_insect(scare)
    >>> gamestate.places["tunnel_0_1"].add_insect(bee)
    >>> scare.action(gamestate)
    >>> bee.action(gamestate)
    >>> bee.place.name
    'tunnel_0_2'
    >>> bee.action(gamestate)
    >>> bee.place.name
    'tunnel_0_3'
    >>> #
    >>> # Same bee should not be scared more than once
    >>> scare.action(gamestate)
    >>> bee.action(gamestate)
    >>> bee.place.name
    'tunnel_0_2'
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> # Testing long status stack
    >>> scary = ScaryThrower()
    >>> slow = SlowThrower()
    >>> bee = Bee(3)
    >>> gamestate.places["tunnel_0_0"].add_insect(scary)
    >>> gamestate.places["tunnel_0_1"].add_insect(slow)
    >>> gamestate.places["tunnel_0_3"].add_insect(bee)
    >>> scary.action(gamestate) # scare bee once
    >>> gamestate.time = 0
    >>> bee.action(gamestate) # scared
    >>> bee.place.name
    'tunnel_0_4'
    >>> for _ in range(3): # slow bee three times, for a total of 5 turns
    ...    slow.action(gamestate)
    >>> gamestate.time = 1
    >>> bee.action(gamestate) # scared, but also slowed for 5 more turns, so it doesn't move back yet
    >>> bee.place.name
    'tunnel_0_4'
    >>> gamestate.time = 2
    >>> bee.action(gamestate) # after this, no longer scared, but still slowed for 4 turns
    >>> bee.place.name #  it's an even turn, so it can be scared and move backwards
    'tunnel_0_5'
    >>> gamestate.time = 3
    >>> bee.action(gamestate) # slowed for 3 more turns
    >>> bee.place.name
    'tunnel_0_5'
    >>> gamestate.time = 4
    >>> bee.action(gamestate) # slowed for 2 more turns
    >>> bee.place.name
    'tunnel_0_4'
    >>> gamestate.time = 5
    >>> bee.action(gamestate) # slowed for 1 more turns
    >>> bee.place.name
    'tunnel_0_4'
    >>> gamestate.time = 6
    >>> bee.action(gamestate) # no longer slowed
    >>> bee.place.name
    'tunnel_0_3'
    >>> gamestate.time = 7
    >>> bee.action(gamestate) # no longer slowed
    >>> bee.place.name
    'tunnel_0_2'
    >>> gamestate.time = 8
    >>> bee.action(gamestate) # no longer slowed
    >>> bee.place.name
    'tunnel_0_1'
    >>> from ants import *
    >>> beehive, layout = Hive(AssaultPlan()), dry_layout
    >>> dimensions = (1, 9)
    >>> gamestate = GameState(beehive, ant_types(), layout, dimensions)
    >>> scary = ScaryThrower()
    >>> slow = SlowThrower()
    >>> bee = Bee(3)
    >>> gamestate.places["tunnel_0_0"].add_insect(scary)
    >>> gamestate.places["tunnel_0_1"].add_insect(slow)
    >>> gamestate.places["tunnel_0_3"].add_insect(bee)
    >>> slow.action(gamestate) # slow bee
    >>> scary.action(gamestate) # scare bee
    >>> bee.place.name
    'tunnel_0_3'
    >>> gamestate.time = 0
    >>> bee.action(gamestate) # scared and slowed - even game time, so *can* back away
    >>> bee.place.name
    'tunnel_0_4'
    >>> gamestate.time = 1
    >>> bee.action(gamestate) # scared and slowed - odd game time, so *cannot* back away
    >>> bee.place.name
    'tunnel_0_4'
    >>> gamestate.time = 2
    >>> bee.action(gamestate) # scared and slowed - even game time, so *can* back away, no longer scared after this
    >>> bee.place.name
    'tunnel_0_5'
    >>> gamestate.time = 3
    >>> bee.action(gamestate) # slowed - odd game time, cannot move forward
    >>> bee.place.name
    'tunnel_0_5'
    >>> gamestate.time = 4
    >>> bee.action(gamestate) # slowed - even game time, moves forward
    >>> bee.place.name
    'tunnel_0_4'
    >>> gamestate.time = 3
    >>> bee.action(gamestate) # neither scared nor slowed
    >>> bee.place.name
    'tunnel_0_3'
    >>> gamestate.time = 2
    >>> bee.action(gamestate) # neither scared nor slowed
    >>> bee.place.name
    'tunnel_0_2'
    """
