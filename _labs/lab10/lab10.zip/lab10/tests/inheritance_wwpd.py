from pytest_grader import points


@points(0)
def inheritance_wwpd():
    """What Would Python Display?

    >>> class A:
    ...     x, y = 0, 0
    ...     def __init__(self):
    ...         return
    >>> class B(A):
    ...     def __init__(self):
    ...         return
    >>> class C(A):
    ...     def __init__(self):
    ...         return
    >>> print(A.x, B.x, C.x)
    LOCKED: 4f8f7215162cbd83
    >>> B.x = 2
    >>> print(A.x, B.x, C.x)
    LOCKED: 7e65b4dc6f190eb4
    >>> A.x += 1
    >>> print(A.x, B.x, C.x)
    LOCKED: 174d1b8843115146
    >>> obj = C()
    >>> obj.y = 1
    >>> C.y == obj.y
    LOCKED: 8187ff222407a918
    >>> A.y = obj.y
    >>> print(A.y, B.y, C.y, obj.y)
    LOCKED: 066c172dc8c866ae
    """
